<?php
/**
 * Syed Ejaz Digital Library - Theme Functions
 * 
 * @package SyedEjazLibrary
 * @version 1.0.0
 */

if (!defined('ABSPATH')) exit;

define('SEJAZ_VERSION', '1.0.0');
define('SEJAZ_DIR', get_template_directory());
define('SEJAZ_URI', get_template_directory_uri());

/* ========================================
   1. THEME SETUP
   ======================================== */
add_action('after_setup_theme', function() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', ['search-form', 'comment-form', 'gallery', 'caption']);
    
    // Custom image sizes for books
    add_image_size('book-cover', 400, 600, true);
    add_image_size('book-cover-large', 800, 1200, true);
    add_image_size('gallery-thumb', 600, 800, true);
    
    // Register nav menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'sejaz-library'),
        'footer'  => __('Footer Menu', 'sejaz-library'),
    ]);
});

/* ========================================
   2. ENQUEUE STYLES & SCRIPTS
   ======================================== */
add_action('wp_enqueue_scripts', function() {
    // TailwindCSS CDN
    wp_enqueue_script('tailwindcss', 'https://cdn.tailwindcss.com?plugins=forms,container-queries', [], null);
    
    // Google Fonts + Material Symbols
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&family=Inter:wght@400;500;600&family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap', [], null);
    
    // Theme style
    wp_enqueue_style('sejaz-style', get_stylesheet_uri(), ['google-fonts'], SEJAZ_VERSION);
    
    // Tailwind Config
    wp_add_inline_script('tailwindcss', file_get_contents(SEJAZ_DIR . '/assets/js/tailwind-config.js'));
    
    // Theme JS
    wp_enqueue_script('sejaz-main', SEJAZ_URI . '/assets/js/theme.js', [], SEJAZ_VERSION, true);
    
    // Localize for AJAX
    wp_localize_script('sejaz-main', 'sejaz', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('sejaz_nonce'),
        'home_url' => home_url('/'),
    ]);
});

/* ========================================
   3. CUSTOM POST TYPE: BOOKS
   ======================================== */
add_action('init', function() {
    register_post_type('book', [
        'labels' => [
            'name'               => 'Books',
            'singular_name'      => 'Book',
            'add_new'            => 'Add New Book',
            'add_new_item'       => 'Add New Book',
            'edit_item'          => 'Edit Book',
            'all_items'          => 'All Books',
            'search_items'       => 'Search Books',
            'not_found'          => 'No books found',
        ],
        'public'             => true,
        'has_archive'        => true,
        'rewrite'            => ['slug' => 'books'],
        'show_in_rest'       => true,
        'menu_icon'          => 'dashicons-book-alt',
        'supports'           => ['title', 'editor', 'thumbnail', 'excerpt'],
        'taxonomies'         => ['book_category'],
    ]);

    // Book Category Taxonomy
    register_taxonomy('book_category', 'book', [
        'labels' => [
            'name'          => 'Book Categories',
            'singular_name' => 'Book Category',
            'search_items'  => 'Search Categories',
            'all_items'     => 'All Categories',
            'edit_item'     => 'Edit Category',
            'add_new_item'  => 'Add New Category',
        ],
        'hierarchical' => true,
        'public'       => true,
        'rewrite'      => ['slug' => 'book-category'],
        'show_in_rest' => true,
        'show_admin_column' => true,
    ]);

    // Gallery Post Type
    register_post_type('gallery_item', [
        'labels' => [
            'name'          => 'Gallery',
            'singular_name' => 'Gallery Item',
            'add_new'       => 'Add New Image',
            'add_new_item'  => 'Add New Gallery Item',
            'edit_item'     => 'Edit Gallery Item',
            'all_items'     => 'All Gallery Items',
        ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => ['slug' => 'gallery'],
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-format-gallery',
        'supports'     => ['title', 'thumbnail'],
        'taxonomies'   => ['gallery_category'],
    ]);

    // Gallery Category
    register_taxonomy('gallery_category', 'gallery_item', [
        'labels' => [
            'name'          => 'Gallery Categories',
            'singular_name' => 'Gallery Category',
        ],
        'hierarchical' => true,
        'public'       => true,
        'rewrite'      => ['slug' => 'gallery-category'],
        'show_in_rest' => true,
    ]);
});

/* ========================================
   4. CUSTOM META BOXES FOR BOOKS
   ======================================== */
add_action('add_meta_boxes', function() {
    add_meta_box('book_details', 'Book Details', 'sejaz_book_meta_box', 'book', 'normal', 'high');
    add_meta_box('gallery_details', 'Gallery Details', 'sejaz_gallery_meta_box', 'gallery_item', 'normal', 'high');
});

function sejaz_book_meta_box($post) {
    wp_nonce_field('sejaz_book_meta', 'sejaz_book_nonce');
    $meta = get_post_meta($post->ID);
    $title_ur = $meta['_book_title_ur'][0] ?? '';
    $author   = $meta['_book_author'][0] ?? 'Syed Ejaz Gillani';
    $year     = $meta['_book_year'][0] ?? '';
    $pdf_url  = $meta['_book_pdf_url'][0] ?? '';
    $language = $meta['_book_language'][0] ?? 'urdu';
    ?>
    <table class="form-table">
        <tr><th><label for="book_title_ur">Title (Urdu)</label></th>
            <td><input type="text" id="book_title_ur" name="book_title_ur" value="<?php echo esc_attr($title_ur); ?>" class="regular-text" dir="rtl"></td></tr>
        <tr><th><label for="book_author">Author</label></th>
            <td><input type="text" id="book_author" name="book_author" value="<?php echo esc_attr($author); ?>" class="regular-text"></td></tr>
        <tr><th><label for="book_year">Year</label></th>
            <td><input type="text" id="book_year" name="book_year" value="<?php echo esc_attr($year); ?>" class="small-text"></td></tr>
        <tr><th><label for="book_language">Language</label></th>
            <td><input type="text" id="book_language" name="book_language" value="<?php echo esc_attr($language); ?>" class="regular-text"></td></tr>
        <tr><th><label for="book_pdf_url">PDF Link (Google Drive)</label></th>
            <td><input type="url" id="book_pdf_url" name="book_pdf_url" value="<?php echo esc_url($pdf_url); ?>" class="large-text">
                <p class="description">📌 Upload PDF to Google Drive → Share → "Anyone with link" → Paste link here. URL is auto-converted!</p></td></tr>
    </table>
    <?php
}

function sejaz_gallery_meta_box($post) {
    wp_nonce_field('sejaz_gallery_meta', 'sejaz_gallery_nonce');
    $category = get_post_meta($post->ID, '_gallery_category', true) ?: 'Events';
    ?>
    <table class="form-table">
        <tr><th><label for="gallery_category_text">Category Label</label></th>
            <td><input type="text" id="gallery_category_text" name="gallery_category_text" value="<?php echo esc_attr($category); ?>" class="regular-text">
                <p class="description">e.g. Events, Family, Travel</p></td></tr>
    </table>
    <?php
}

// Save meta
add_action('save_post_book', function($post_id) {
    if (!isset($_POST['sejaz_book_nonce']) || !wp_verify_nonce($_POST['sejaz_book_nonce'], 'sejaz_book_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    
    $fields = ['book_title_ur' => '_book_title_ur', 'book_author' => '_book_author', 'book_year' => '_book_year', 'book_language' => '_book_language'];
    foreach ($fields as $input => $key) {
        if (isset($_POST[$input])) update_post_meta($post_id, $key, sanitize_text_field($_POST[$input]));
    }
    if (isset($_POST['book_pdf_url'])) {
        $url = esc_url_raw($_POST['book_pdf_url']);
        // Auto-convert Google Drive URLs to preview format
        if (preg_match('/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/', $url, $m)) {
            $url = 'https://drive.google.com/file/d/' . $m[1] . '/preview';
        } elseif (preg_match('/drive\.google\.com\/open\?id=([a-zA-Z0-9_-]+)/', $url, $m)) {
            $url = 'https://drive.google.com/file/d/' . $m[1] . '/preview';
        }
        update_post_meta($post_id, '_book_pdf_url', $url);
    }
});

add_action('save_post_gallery_item', function($post_id) {
    if (!isset($_POST['sejaz_gallery_nonce']) || !wp_verify_nonce($_POST['sejaz_gallery_nonce'], 'sejaz_gallery_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['gallery_category_text'])) update_post_meta($post_id, '_gallery_category', sanitize_text_field($_POST['gallery_category_text']));
});

/* ========================================
   5. THEME CUSTOMIZER
   ======================================== */
add_action('customize_register', function($wp_customize) {
    // Hero Section
    $wp_customize->add_section('sejaz_hero', ['title' => 'Homepage Hero', 'priority' => 30]);
    
    $hero_fields = [
        'hero_title'    => ['Hero Title', 'Syed Ejaz Gillani'],
        'hero_subtitle' => ['Hero Subtitle', 'A Pakistani Canadian writer, blogger & Community Coordinator.'],
    ];
    foreach ($hero_fields as $id => $data) {
        $wp_customize->add_setting("sejaz_$id", ['default' => $data[1], 'sanitize_callback' => 'sanitize_text_field']);
        $wp_customize->add_control("sejaz_$id", ['label' => $data[0], 'section' => 'sejaz_hero', 'type' => 'text']);
    }

    // About Section
    $wp_customize->add_section('sejaz_about', ['title' => 'About Section', 'priority' => 31]);
    $wp_customize->add_setting('sejaz_about_title', ['default' => 'Read More, Learn More, Grow More', 'sanitize_callback' => 'sanitize_text_field']);
    $wp_customize->add_control('sejaz_about_title', ['label' => 'About Title', 'section' => 'sejaz_about']);
    $wp_customize->add_setting('sejaz_about_text', ['default' => '', 'sanitize_callback' => 'wp_kses_post']);
    $wp_customize->add_control('sejaz_about_text', ['label' => 'About Text', 'section' => 'sejaz_about', 'type' => 'textarea']);
    
    // Stats
    $stats = ['stat1_num' => ['Stat 1 Number', '7+'], 'stat1_text' => ['Stat 1 Label', 'Digital Books'], 'stat2_num' => ['Stat 2 Number', '120+'], 'stat2_text' => ['Stat 2 Label', 'Global Archives']];
    foreach ($stats as $id => $d) {
        $wp_customize->add_setting("sejaz_$id", ['default' => $d[1], 'sanitize_callback' => 'sanitize_text_field']);
        $wp_customize->add_control("sejaz_$id", ['label' => $d[0], 'section' => 'sejaz_about']);
    }

    // Footer
    $wp_customize->add_section('sejaz_footer', ['title' => 'Footer Settings', 'priority' => 32]);
    $social = ['facebook_url' => 'Facebook URL', 'youtube_url' => 'YouTube URL', 'email_address' => 'Contact Email'];
    foreach ($social as $id => $label) {
        $wp_customize->add_setting("sejaz_$id", ['default' => '', 'sanitize_callback' => 'esc_url_raw']);
        $wp_customize->add_control("sejaz_$id", ['label' => $label, 'section' => 'sejaz_footer']);
    }
    $wp_customize->add_setting('sejaz_footer_desc', ['default' => 'Curating knowledge, preserving heritage, and empowering the future through digital literacy.', 'sanitize_callback' => 'sanitize_text_field']);
    $wp_customize->add_control('sejaz_footer_desc', ['label' => 'Footer Description', 'section' => 'sejaz_footer', 'type' => 'textarea']);
});

/* ========================================
   6. HELPER FUNCTIONS
   ======================================== */
function sejaz_get_book_data($post) {
    return [
        'id'          => $post->ID,
        'title'       => get_the_title($post),
        'title_ur'    => get_post_meta($post->ID, '_book_title_ur', true),
        'author'      => get_post_meta($post->ID, '_book_author', true) ?: 'Syed Ejaz Gillani',
        'year'        => get_post_meta($post->ID, '_book_year', true),
        'category'    => sejaz_get_book_category($post->ID),
        'cover'       => get_the_post_thumbnail_url($post, 'book-cover') ?: '',
        'pdf_url'     => get_post_meta($post->ID, '_book_pdf_url', true),
        'description' => get_the_excerpt($post),
        'language'    => get_post_meta($post->ID, '_book_language', true) ?: 'urdu',
        'permalink'   => get_permalink($post),
    ];
}

function sejaz_get_book_category($post_id) {
    $terms = get_the_terms($post_id, 'book_category');
    return ($terms && !is_wp_error($terms)) ? $terms[0]->name : '';
}

function sejaz_get_book_category_slug($post_id) {
    $terms = get_the_terms($post_id, 'book_category');
    return ($terms && !is_wp_error($terms)) ? $terms[0]->slug : '';
}

// Book card template
function sejaz_render_book_card($book) {
    ?>
    <div class="book-card bg-white dark:bg-slate-800 rounded-xl overflow-hidden flex flex-col h-full shadow-sm border border-gray-100 dark:border-slate-700">
        <div class="relative overflow-hidden aspect-[2/3] bg-gray-50 dark:bg-slate-700 flex items-center justify-center">
            <?php if ($book['cover']): ?>
                <img src="<?php echo esc_url($book['cover']); ?>" alt="<?php echo esc_attr($book['title']); ?>" class="w-full h-full object-contain">
            <?php else: ?>
                <span class="material-symbols-outlined text-6xl text-gray-300">menu_book</span>
            <?php endif; ?>
            <span class="absolute top-3 left-3 text-[10px] font-bold uppercase tracking-widest bg-[#006a6a] text-white px-3 py-1 rounded-full"><?php echo esc_html($book['category']); ?></span>
        </div>
        <div class="flex flex-col flex-grow p-5">
            <h3 class="text-base font-headline font-bold text-on-surface dark:text-white mb-1 line-clamp-2"><?php echo esc_html($book['title']); ?></h3>
            <?php if ($book['title_ur']): ?>
                <p class="urdu-text text-sm text-slate-400 mb-1"><?php echo esc_html($book['title_ur']); ?></p>
            <?php endif; ?>
            <p class="text-xs text-slate-400 mb-3 font-medium"><?php echo esc_html($book['author']); ?> · <?php echo esc_html($book['year']); ?></p>
            <p class="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mb-4"><?php echo esc_html($book['description']); ?></p>
            <div class="mt-auto flex gap-2">
                <a href="<?php echo esc_url($book['permalink']); ?>" class="read-btn flex-1 py-2.5 bg-gray-100 dark:bg-slate-700 text-on-surface dark:text-white font-headline font-semibold rounded-lg text-sm text-center block">Read Online</a>
                <?php if ($book['pdf_url']): ?>
                    <a href="<?php echo esc_url(str_replace('/preview', '/view', $book['pdf_url'])); ?>" target="_blank" rel="noopener noreferrer" class="py-2.5 px-3 bg-gray-100 dark:bg-slate-700 text-on-surface dark:text-white rounded-lg hover:bg-[#006a6a] hover:text-white transition-all" title="Open PDF">
                        <span class="material-symbols-outlined text-[18px]">open_in_new</span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}

/* ========================================
   7. WIDGETS
   ======================================== */
add_action('widgets_init', function() {
    register_sidebar([
        'name'          => 'Footer Widget Area',
        'id'            => 'footer-widgets',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="font-headline font-bold text-sm uppercase tracking-widest mb-3">',
        'after_title'   => '</h4>',
    ]);
});

/* ========================================
   8. DARK MODE COOKIE SUPPORT
   ======================================== */
add_action('wp_head', function() {
    echo "<script>if(localStorage.getItem('theme')==='dark'){document.documentElement.classList.add('dark');document.documentElement.classList.remove('light');}else{document.documentElement.classList.add('light');}</script>\n";
});
